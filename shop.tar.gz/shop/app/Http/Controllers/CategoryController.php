<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

use Crypt_RSA;

class CategoryController extends Controller {

  public function index() {
    return View('category.index');
  }

  public function store(Request $request) {
    echo 'store';
    echo '<br><br>';
    var_dump($request->all());
    echo '<br><br>';
    var_dump($request->get('email'));
    echo '<br><br>';
    var_dump($request->get('notExistField'));
  }

  public function req7943(Request $request) {
    $rsa = new Crypt_RSA();
    $rsa->setHash('sha1');
    $rsa->setMGFHash('sha1');
    $rsa->setEncryptionMode(CRYPT_RSA_ENCRYPTION_OAEP);
    $rsa->setPrivateKeyFormat(CRYPT_RSA_PRIVATE_FORMAT_PKCS1);
    $rsa->setPublicKeyFormat(CRYPT_RSA_PUBLIC_FORMAT_PKCS1);
    /*$cipher = base64_decode("TgUnISM1acjy2Ci9vKfausxqIdllGnlJjjFMd2XCCQVQKvu/ZtqiJkvgjHHdrP3k8cC9hPo4w2oe
    3JoeBVQtRopQWfwirEsN/wrHt0O8L/qWE9S0Y2H2nX4N1dP+La0uSxCi+p0nAsThknq/8XuapNEX
    5Da+V+eHwooRlpCjyIyyxLqfRYC6VFpwBOh5+gIJHrkdbE8R+ivD97ZGYv6q/gJJrCOgfsiEYWMJ
    GhK3F1Yyug2v/ksiVvfPdOqDfmBVWA76gGdfZQbmQ8fvJNY9otSWu7V3BrqvLyPW8Ijby+RZGsGU
    7R4xvEk8DdiLpP4zqs9z6BEnh2VaK0g8OSvsLNyUeHg8/nco4Jjs7zrKp896Yy2CCgA8Livdfaxi
    htcoqxN7VeaOI8MqgptrFhFUr7Elb1Dd6aprYOXiTor/1pkwawOlpPM1XOpzpZBXeIa/j6NPlMXo
    CLfE1V3taYNmv130/9Dy1KsT0BZ6c5BNG42dVBH+iH8Etmi4pOQw1bIZeiHemTC2hwi29Fx3hMZh
    4ESKgW7JT+BN1Wtr1pMbXHWxBsxxZflc3ms4gnzAa2U6UfHHvFz+vt7aX1FmknG1sDmdnyJCnMhH
    MHZGrdPMlexN4zl8uzLKR97J7zT5tcW3HKbk0LVlXWVE1YV+8f5kPDmL78N0kxQ4yv2DZBaCE+E=
    ");*/
    $jsonString = $request->get('req7943');
    $jsonArray = json_decode($jsonString, true);

    foreach ($jsonArray as $key => $value) {
      $cipher = base64_decode($value);
      $privateKey = base64_decode("LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQ0KTUlJSktRSUJBQUtDQWdFQXpmOWRYMVR6RXZiV3VHaHByaStVaHdFYTlOcUNwZ3NULzlQb1A2dzJhWGx0cWJBMg0KZVFyQW5BKzlpcTFhMlVxRE1hQ0g4VTUyTDYwSG5Jc2pZTmNGZXRHUDJIVVJhYkhuanJyb01YbXIvNE5nR2F1WA0KQ1JvUHF0dDAzNzRSbXJtY2xUTUxYU3p3bUtGZjNZV2w2R09CU25PcWRrZkw3VldiUjBzdmgzTmpFSUp0bThycw0KSXdpY25WMDFGY3F6eDl3em9Dem9vYUtZY0MvOVFxSGJHekE0dy8rQlFlZk1YMExheWFmckhQLzdvdVhlNHpKUQ0KWWp4WEMxdklmVEcyYjVCNWpkTGpNSHVjTDA3MC9zbVFqSFNFcEF2V1c1Y0pZUVQrY200cnF3eVlRTVg0dkZiTQ0KNXZYTUVxdzFNSjYzMGdZMEZoY1VqVGh2ZVpuOHdmbTlJTnM1dCt1b3V2V1lSWnpDSU1ockVOdENtOEN1cnRoWg0KWXVaZlB4SHZ6cEFUaDlMUFJEVk9BMld2cENGT3RqTnVhbHlUUVRHN2xadjJWVU9SK2NCSTBlcDBuVy82ZWVoVg0KazJEUllaYjNPTDRqVEx1bk54Sk15LzA0MHBGSmJsOXhhZkc0QnZMeG9GNmNiSFBHdjZsSGxiNzdyRzJleUxpLw0KakdSY0ZiZlh3NGxuYlhBRVh1Y2Z3RGMwZFdYTWxVcVl0T0dsbWp1djh6VXVDcHZNTVZEcm5aVkd4cGtZdERZYg0KRXNXa2J2c1NRbU41VkxjTC92b3FkeTJzMzBoUUl1K3NoM3d1dHhpVysrcEhvbTVteXR2dUNDUzB1WlF3WVJiMQ0KREc5dlJ6ZkZINys3K3FXUkNqSUZzTHdjNzFGekhkOEZ3NHhKUkkwSUk0RDZvV0dxdi9PSWVta1pwNTBDQXdFQQ0KQVFLQ0FnQlM3WDJhVmlsd3Rmd2t5cXZZbW9EeGhHbGtydDZ2bDRBYW1pVkNGTUxtM1NKZmtIZXRiTDJ6VmNiWg0KSUFhVnVTQnRoeEdTL0NJcCtUODZMdTAwRy91eHdORm1zMklxS1p0dFl5TDhYOTMxQTk5WkZqRzhVVWlEWU11Qg0KRXhRbE5KbXJtcHYxaTVUajdQc1p3NmJSa2RWSHNwNnA5U2RNU1EwMHV6ak1ENUNPNGVMY04rbXVCTlovcHprcQ0KcDZxT1I4Qmt1QStDbW1GQnNLQUZCZ0dkeFdEa3ptUXJzdlFjV1Y2WWxjZlpxZGVVY1hPMEJOcEZZY01zNkdzaQ0Kc3pPZFlBei9JaW1ocC9GdFBoejB3UkkyNk9WSTRSY1BVaE5OZ21Rb2p0OTNnWjk5Vy9WUlpLUWlTa3M0TFNsUQ0KaEdTOTRROXc0U085NGoxR044NkFERml0OUhNY05ONVhidDRwdjIzNkVwZzNyUktoZ1RlVGkvUUhLL0VHb0lWVg0KaS81MGR5ZkZURGxrWnIyZGVJQmllUWJIcm1kMS9LSzlnbWlubXM4V0RIRUljNEgxUnlyeHRXTHFFb1JwSEVMVw0KcGxhVmpicmN1N2ZMc2Yzc2VydHlHcnowZTdqS2xmN0ZRSVlCNXV5U2thQkkrSkhjc0JqU09kYzZDQ3F2NC9JVQ0KbGxqWm9wNzE4K0hvcmhvajNiR3VuZFZpQjVPL3Q3Z2NxN01CVVpOWW05R2lYWDRpZ3BwekZOeDgwT2F5RzNjWQ0KT0xnMU1QMFhGYlhKK0dhT1NrSkJMY29OTndaS2FYc3BKNkdqSXRBWlJ6RGM5Z2FzVFM0bXRVWnY4RGVNa2w4MA0KeHEzZjI3Q1JtRkppYk9TVW5hQ2RKak85V3plSFViT0NHaVByUGUybHVSNlZYV2hFd1FLQ0FRRUErczNSU0phbg0Kcm5BeXFJeEtER2NhRXdwZi9sb3R5UWlEM0EwRjlHbDB0TlVTQTRsSjN0OGlBSUNibkNSbGIyU3lBNi8ydzFhUQ0KcW44dm5lMWMzei9pZE95QnNqemFZVG1FZEVoNjFtSXVTcFhvSWFQNWhBZUZFY0JVNzZuS1pxcEJ5ZmpDY3hqSg0KalZuQk9XM1VWZmtuRXQrMW4xbm0wM1BXN3ByaUpnclFHd3VxMGlXMWxtM21MVThoeW5rdXRtRitUVU9CVExPYQ0KTkJhbXZsRjFKeUFpcjFCZGE0NFQzVGxqSmhlYld2eWhYaFFBSmVUTFRJbDBudFFGQkE2ajBvLzRGR2Y1cTRsKw0KTnpUVEFNOEVJVnhDampaRjNjRVpFTjdHdW1TaW1pajVpOWZlaXIwMG0zYU1PQk5FRXQrVXNNSmhOaU82cGZGeQ0KZlI5L1BOMzFVdHpDY1FLQ0FRRUEwa1BvakZicGRIMDJHMnhmZnJ3bzJNZ1RqTS9heEtzN0tWbUZjRysrZ2tIKw0KMkZQRGM2UUpVbXRHMzFvOGRNcnNRSS9RMDNYY0VNWjVwQkd2UnZsTTNnb3Z2OVBrclppcHdCdXJ4eWl6cWhiaQ0KR21oRFBJK1ZsalAzQkgyZjArU25saktqTHZ6a3NFYjJVcmFZVHd1d0hmRHF1amE3b0ptY0hYMjdSNG5VN1VINg0KQVQzaGhteGx3Qzhwbi9nWGI2K0MyOGtPOG1OdXZYK2c0UGFINFMyQUhHS2ZqWGtpNmFvMnpsSWNVVmdyT0J4aw0KT0ZVOURDWEppRDc3ZTdVUi9Da1VxTDZoTDVHbEQyM2JCbDMxZjRWdExRNmhOZ2RRVkY4UTZjaU43emhlKzd4NQ0KLzVBdk5ScXgxRG9nZDhCcmcwUitVU1pMM2FWVlZxQXlHazR5NFp4MTdRS0NBUUVBakJsbW0vYlVTa1FRZUVpTg0Kb0tvRFRibVE3K051Q2d1QXBPNTljZzlxaXcwdTE5emI3K3lTOE5ibWxlMWE0RVBPa1BLOWxGYUp6MFBtMUlCZw0KVGJGQkRmR0RiWTVDcXViWFQ2R2hSSnBwbzI1ajBrN250ZElCaW0zMnhENERleUFHU2cxMGlaakNGZnlhVER0Rw0KenBPME9QM1FWZWlCWVlNbS8vaHk5YTg2bXJFRXhna2NpNkJ1WU1jQWFEc1RWZnZWOHRFUHJFbnpqTDlPZTZmRA0KR296Lzh4Q2didEZaMVUwV1RwUUhTMmN0dVFEUktGbkxHc0Q1N1RNZ2JpakRhSDdWcElpRVZrY2l3ekgxNEZERA0Kek9MZHB0VTRaK3hTMVRLc3JqaERBSHg5RVpvUGpVNnQwVjRDYTl5UFBUKzVycGVXZUFpelhia25MQy9wQXBZMg0KVVFoU2NRS0NBUUJCQlRMaVF2WUtTYlh6b1AyZXlUeXdYSjUvQ3IrUjFZbUQ3ZVR2c2Y1dGRVOERRbFBNYk10ZA0KSzBOTlNqQXJ4Wnh0RW92MitCbEhMcmpxM1hVZ00zTnJyaWE1NFNKejlDTjUvcFNPRDY0UFNPZytWa09FZExwRA0KS21xV2Z1cHZzZU9JOUx1MWlncUY0RXZIcENOUlBrSUY0RHdWdlZzai9KeGtHajlSamZQRU1vVEc0WVhkOWFNNQ0KWE53NFZaV1p1ZUp6YUtjd21VTGpZcFl6T3NrbC90WUE4Ulo1dngzbXQvWWVzeEdDcmdzZlhOZzQrMUxYY00veg0KUzlha21JZXBQR0xoRTZId2ZjOVhDQmVVem5WZUs3cHBGbjhQb0E5ZEo5Q3BHcFdaaGdzSk9XMVlkQlBGRGk0eg0KZkk0UnVmVUZNS2NISFJxVXZjMjM3ZTNRYUtJZlZpeTVBb0lCQVFDOUl2azJ4Z1JGbDNpU0FzOE9VY21zVGkzSQ0KZElVaUk0by9xWUZicm1BSHN1ZXRZY2NqS0JpNTFna2tZc2VlaXUvTjdBOGNrRTNnekFjb2hYWkJacWUvZVhEcQ0KaC9mV01wZUp5Ujh3Q2NrdzlwSEx3R1djWE5lK2N2RHpoL05BMStHU3lmeTV1V3d5TDhNVHlOUElVSFpSSCtGNQ0KUEJNcUxHWFVYM3MwVFlveUZWQjFNNXFwY3FYeEQ3eDd1NXVnVkQ4VUpQVnZZbHVUTTVMZ0NmTTlPM1Rya3BEMA0KOVhVcVB4M1dYZjQvSXhOR0FjZDVNaGZXdG8zdC84TlpVOSs5SVA5RENvNkNsN0JvUU1RU2haOXFqNFBtRmFNVA0KbHZFNndFQjZtVVlMeGFjbGNvVnpVd1pSSUptL1hBbmVhQWRVRDZVUURTa2U3M0xzcnpjQzdqeXFvU0ozDQotLS0tLUVORCBSU0EgUFJJVkFURSBLRVktLS0tLQ==");

      // Decryption
      $rsa->loadKey($privateKey);
      $decryptedContact = $rsa->decrypt($cipher);
      $contacts = DB::insert('insert into contactjson (data) values(?)', [$decryptedContact]);

      //var_dump($key);
      //var_dump((sizeof($jsonArray)-1));

      if($key == (sizeof($jsonArray)-1)) {
        //var_dump(json_decode($decryptedContact, true));
        //var_dump(json_decode($decryptedContact, true)["id"]);
        $lastContactIDReceived = json_decode($decryptedContact, true)["id"];
        echo $lastContactIDReceived;
      }

    }
  }


  public function req7944(Request $request) {
    $servers = DB::table('servers')
              ->where('servers.regcount', '<', 1000)
              //->inRandomOrder()
              ->orderBy('regcount', 'asc')
              ->get();
    echo json_encode($servers[0]);
  }
}
