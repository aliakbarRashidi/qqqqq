<?php echo $DEVELOPER_HELLO_SCRIPT; ?>

<h6><?php echo e($DEVELOPER_NAME); ?></h6>
<form method="post" action="<?php echo e(url('admin/category/store')); ?>">
  <?php echo e(csrf_field()); ?>

  <input type="text" name="name">
  <input type="text" name="email">
  <input type="submit">
</from>
